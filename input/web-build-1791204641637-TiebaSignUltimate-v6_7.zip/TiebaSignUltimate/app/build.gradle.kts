plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.junshi.tieba"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.junshi.tieba"
        minSdk = 26
        targetSdk = 34
        versionCode = 4
        versionName = "2.2.1"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // 用 debug 证书签名，这样 assembleRelease 产出的 APK 可以直接安装
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.work:work-runtime-ktx:2.8.1")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
}
