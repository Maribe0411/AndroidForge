package com.junshi.tieba
import android.Manifest
import android.os.*
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
class MainActivity:ComponentActivity(){private val p=registerForActivityResult(ActivityResultContracts.RequestPermission()){};override fun onCreate(b:Bundle?){super.onCreate(b);if(Build.VERSION.SDK_INT>=33)p.launch(Manifest.permission.POST_NOTIFICATIONS);setContent{val s=remember{SecureStore(this)};var bd by remember{mutableStateOf(s.bduss)};var st by remember{mutableStateOf(s.stoken)};var auto by remember{mutableStateOf(false)};var run by remember{mutableStateOf(false)};var logs by remember{mutableStateOf(listOf("就绪：凭证只存本机加密存储"))};val scope=rememberCoroutineScope();MaterialTheme{Scaffold(topBar={TopAppBar(title={Text("🟦 贴吧签到助手 Ultimate")})}){pad->LazyColumn(Modifier.padding(pad).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{OutlinedTextField(bd,{bd=it},Modifier.fillMaxWidth(),label={Text("BDUSS")},visualTransformation=PasswordVisualTransformation())};item{OutlinedTextField(st,{st=it},Modifier.fillMaxWidth(),label={Text("STOKEN（建议填写）")},visualTransformation=PasswordVisualTransformation())};item{Button({s.bduss=bd.trim();s.stoken=st.trim();logs=listOf("登录态已保存")+logs},Modifier.fillMaxWidth()){Text("保存登录态")}};item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("每日自动签到");Switch(auto,{auto=it;if(it)Scheduler.start(this@MainActivity)else Scheduler.stop(this@MainActivity)})}};item{Button(enabled=!run,onClick={run=true;scope.launch{try{val r=TiebaClient(s).run{m->logs=(listOf(m)+logs).take(300)};logs=listOf("完成：${r.success} 成功 / ${r.skipped} 跳过 / ${r.failed} 失败")+logs}catch(e:Exception){logs=listOf("失败：${e.message}")+logs}finally{run=false}}},Modifier.fillMaxWidth()){Text(if(run)"签到中…" else "🚀 立即签到")}};item{Text("运行日志",style=MaterialTheme.typography.titleLarge)};items(logs){Text("• $it")};item{Text("安全提示：BDUSS/STOKEN 是登录凭证，不要发给别人或提交 GitHub。接口变化、限速和账号风控都可能导致失败。",style=MaterialTheme.typography.bodySmall)}}}}}}
