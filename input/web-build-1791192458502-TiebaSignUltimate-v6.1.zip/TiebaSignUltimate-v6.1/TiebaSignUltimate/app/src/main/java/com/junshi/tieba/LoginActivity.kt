package com.junshi.tieba

import android.app.Activity
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast

/**
 * 在 App 内打开百度登录页。登录成功后自动（每秒轮询）读取 BDUSS；
 * 如果一直没读到，也可以点底部按钮手动触发读取。
 */
class LoginActivity : Activity() {

    private var done = false
    private val handler = Handler(Looper.getMainLooper())
    private val poll = object : Runnable {
        override fun run() {
            if (done) return
            checkCookie(false)
            handler.postDelayed(this, 1000)
        }
    }

    private val urls = listOf(
        "https://tieba.baidu.com",
        "https://tiebac.baidu.com",
        "https://www.baidu.com",
        "https://baidu.com",
        "https://m.baidu.com",
        "https://passport.baidu.com",
        "https://wappass.baidu.com"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL

        val webView = WebView(this)
        root.addView(
            webView,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )

        val doneBtn = Button(this)
        doneBtn.text = "我已登录，点此完成"
        doneBtn.isAllCaps = false
        doneBtn.setTextColor(Color.WHITE)
        val btnBg = GradientDrawable()
        btnBg.cornerRadius = 24f
        btnBg.setColor(Color.parseColor("#3B4CCA"))
        doneBtn.background = btnBg
        root.addView(
            doneBtn,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
        setContentView(root)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                checkCookie(false)
            }
        }

        doneBtn.setOnClickListener { checkCookie(true) }

        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        cm.setAcceptThirdPartyCookies(webView, true)
        val loginUrl = "https://wappass.baidu.com/passport/?login&u=" +
            Uri.encode("https://tieba.baidu.com/")
        // 先清掉旧 Cookie，避免读到上一个账号的登录态
        cm.removeAllCookies {
            webView.loadUrl(loginUrl)
            handler.postDelayed(poll, 1000)
        }
    }

    private fun allCookies(): String {
        val cm = CookieManager.getInstance()
        return urls.mapNotNull { cm.getCookie(it) }.joinToString(";")
    }

    private fun readCookie(all: String, name: String): String? {
        return all.split(";")
            .map { it.trim() }
            .firstOrNull { it.startsWith("$name=") }
            ?.substringAfter("=")
    }

    private fun checkCookie(manual: Boolean) {
        if (done) return
        val all = allCookies()
        val found = readCookie(all, "BDUSS") ?: readCookie(all, "BDUSS_BFESS")
        if (!found.isNullOrEmpty()) {
            done = true
            handler.removeCallbacks(poll)
            val p = Prefs(this)
            p.bduss = found
            p.lastSign = ""
            Toast.makeText(this, "登录成功", Toast.LENGTH_SHORT).show()
            setResult(RESULT_OK)
            finish()
        } else if (manual) {
            // 只显示 Cookie 名称（不含值），方便排查
            val names = all.split(";")
                .map { it.trim().substringBefore("=") }
                .filter { it.isNotEmpty() }
                .distinct()
                .joinToString(",")
            Toast.makeText(
                this,
                "还没读到 BDUSS。已有 Cookie：" + names.take(150),
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(poll)
    }
}
