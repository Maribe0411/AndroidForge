package com.junshi.tieba

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import kotlin.random.Random

data class Forum(val id: String, val name: String)

data class SignSummary(val total: Int, val success: Int, val already: Int, val failed: Int)

/**
 * 思路参考 GitHub 上常见的贴吧签到脚本（如 ghosx/TieBaSign）：
 * 1. 用 BDUSS 请求 tbs
 * 2. 用客户端接口分页获取关注的吧
 * 3. 用客户端签到接口逐个签到（参数按 key 排序后拼接 + "tiebaclient!!!" 做 MD5 签名）
 * 接口是非公开接口，百度随时可能调整，失效时需要更新这里。
 */
class TiebaClient(private val bduss: String) {

    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private val tbsUrl = "https://tieba.baidu.com/dc/common/tbs"
    private val likeUrl = "https://c.tieba.baidu.com/c/f/forum/like"
    private val signUrl = "https://c.tieba.baidu.com/c/c/forum/sign"
    private val ua = "Mozilla/5.0 (Linux; Android 10; MI 5) AppleWebKit/537.36 " +
        "(KHTML, like Gecko) Chrome/80.0.3987.162 Mobile Safari/537.36"

    private fun baseParams(): MutableMap<String, String> = mutableMapOf(
        "_client_type" to "2",
        "_client_version" to "9.7.8.0",
        "_phone_imei" to "000000000000000",
        "model" to "MI+5",
        "net_type" to "1"
    )

    private fun md5(s: String): String {
        val bytes = MessageDigest.getInstance("MD5").digest(s.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    /** 按 key 排序拼接，末尾加 tiebaclient!!!，MD5 后转大写作为 sign。 */
    private fun signedBody(params: Map<String, String>): FormBody {
        val sorted = params.toSortedMap()
        val raw = sorted.entries.joinToString("") { it.key + "=" + it.value } + "tiebaclient!!!"
        val builder = FormBody.Builder()
        for ((k, v) in sorted) builder.add(k, v)
        builder.add("sign", md5(raw).uppercase())
        return builder.build()
    }

    private fun parseJson(body: String): JSONObject {
        try {
            return JSONObject(body)
        } catch (e: Exception) {
            throw IllegalStateException("返回内容不是 JSON：" + body.take(150))
        }
    }

    private fun execute(request: Request): String {
        http.newCall(request).execute().use { resp ->
            if (!resp.isSuccessful) throw IllegalStateException("HTTP ${resp.code}")
            return resp.body?.string() ?: ""
        }
    }

    private fun getTbs(): String {
        val req = Request.Builder()
            .url(tbsUrl)
            .header("Cookie", "BDUSS=$bduss")
            .header("User-Agent", ua)
            .build()
        val json = parseJson(execute(req))
        if (json.optInt("is_login") != 1) {
            throw IllegalStateException("BDUSS 无效或已过期，请重新获取")
        }
        return json.getString("tbs")
    }

    private suspend fun getForums(onLog: (String) -> Unit): List<Forum> {
        val result = LinkedHashMap<String, Forum>()
        var page = 1
        while (page <= 200) {
            val params = baseParams()
            params["BDUSS"] = bduss
            params["_client_id"] = "wappc_1534235498291_488"
            params["from"] = "1008621y"
            params["page_no"] = page.toString()
            params["page_size"] = "200"
            params["timestamp"] = (System.currentTimeMillis() / 1000).toString()
            params["vcode_tag"] = "11"

            val req = Request.Builder()
                .url(likeUrl)
                .header("User-Agent", ua)
                .post(signedBody(params))
                .build()
            val json = parseJson(execute(req))

            val list = json.optJSONObject("forum_list")
            if (list == null && json.optString("error_code", "0") != "0") {
                throw IllegalStateException(
                    "获取关注贴吧失败，错误码 " + json.optString("error_code") +
                        " " + json.optString("error_msg")
                )
            }
            if (list == null && page == 1) {
                onLog("接口返回（供排错）：" + json.toString().take(200))
            }
            if (list != null) {
                for (key in listOf("non-gconforum", "gconforum")) {
                    val arr = list.optJSONArray(key) ?: continue
                    for (i in 0 until arr.length()) {
                        val item = arr.getJSONObject(i)
                        val id = item.optString("id")
                        val name = item.optString("name")
                        if (id.isNotEmpty() && name.isNotEmpty()) {
                            result[id] = Forum(id, name)
                        }
                    }
                }
            }
            if (json.optString("has_more") != "1") break
            page++
            delay(300)
        }
        return result.values.toList()
    }

    /** 返回：0 = 签到成功，1 = 已经签到过，2 = 失败（msg 里有原因） */
    private fun signOne(forum: Forum, tbs: String): Pair<Int, String> {
        val params = baseParams()
        params["BDUSS"] = bduss
        params["fid"] = forum.id
        params["kw"] = forum.name
        params["tbs"] = tbs
        params["timestamp"] = (System.currentTimeMillis() / 1000).toString()

        val req = Request.Builder()
            .url(signUrl)
            .header("User-Agent", ua)
            .header("Connection", "Keep-Alive")
            .post(signedBody(params))
            .build()
        val json = parseJson(execute(req))
        val code = json.optString("error_code", "")
        return when (code) {
            "0" -> Pair(0, "")
            "160002" -> Pair(1, "")
            else -> Pair(2, "错误码 $code ${json.optString("error_msg")}".trim())
        }
    }

    suspend fun signAll(onLog: (String) -> Unit): SignSummary = withContext(Dispatchers.IO) {
        require(bduss.isNotBlank()) { "未填写 BDUSS" }

        val tbs = getTbs()
        onLog("登录状态正常")
        val forums = getForums(onLog)
        onLog("共关注 ${forums.size} 个贴吧")

        var success = 0
        var already = 0
        var pending = forums

        // 最多尝试 3 轮，失败的贴吧下一轮重试
        for (round in 1..3) {
            if (pending.isEmpty()) break
            if (round > 1) {
                onLog("第 $round 轮重试，剩余 ${pending.size} 个")
                delay(5000)
            }
            val failedNow = mutableListOf<Forum>()
            for (forum in pending) {
                try {
                    val (state, msg) = signOne(forum, tbs)
                    when (state) {
                        0 -> {
                            success++
                            onLog("${forum.name}吧：签到成功")
                        }
                        1 -> {
                            already++
                            onLog("${forum.name}吧：今天已签到")
                        }
                        else -> {
                            failedNow.add(forum)
                            onLog("${forum.name}吧：失败 $msg")
                        }
                    }
                } catch (e: Exception) {
                    failedNow.add(forum)
                    onLog("${forum.name}吧：异常 ${e.message}")
                }
                delay(Random.nextLong(800, 2000))
            }
            pending = failedNow
        }
        SignSummary(forums.size, success, already, pending.size)
    }
}
