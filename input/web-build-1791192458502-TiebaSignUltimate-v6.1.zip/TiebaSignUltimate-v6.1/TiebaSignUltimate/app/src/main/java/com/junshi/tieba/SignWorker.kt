package com.junshi.tieba

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

class SignWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val bduss = Prefs(applicationContext).bduss
        if (bduss.isBlank()) return Result.failure()
        return try {
            val r = TiebaClient(bduss).signAll { }
            if (r.failed == 0) Prefs(applicationContext).lastSign = Prefs.today()
            notifyUser("成功 ${r.success} · 已签 ${r.already} · 失败 ${r.failed}")
            Result.success()
        } catch (e: Exception) {
            notifyUser("签到失败：${e.message}")
            if (runAttemptCount < 2) Result.retry() else Result.failure()
        }
    }

    private fun notifyUser(text: String) {
        val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "tieba_sign"
        nm.createNotificationChannel(
            NotificationChannel(channelId, "贴吧签到", NotificationManager.IMPORTANCE_DEFAULT)
        )
        val n = Notification.Builder(applicationContext, channelId)
            .setSmallIcon(android.R.drawable.ic_popup_sync)
            .setContentTitle("贴吧签到助手")
            .setContentText(text)
            .setAutoCancel(true)
            .build()
        nm.notify(7, n)
    }
}
