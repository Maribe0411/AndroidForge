package com.junshi.tieba

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 凭证只保存在应用私有存储中，不会上传到任何服务器。 */
class Prefs(context: Context) {
    private val sp = context.applicationContext
        .getSharedPreferences("tieba", Context.MODE_PRIVATE)

    var bduss: String
        get() = sp.getString("bduss", "") ?: ""
        set(value) {
            sp.edit().putString("bduss", value).apply()
        }

    var auto: Boolean
        get() = sp.getBoolean("auto", true)
        set(value) {
            sp.edit().putBoolean("auto", value).apply()
        }

    /** 最近一次完整签到成功的日期（yyyy-MM-dd） */
    var lastSign: String
        get() = sp.getString("last_sign", "") ?: ""
        set(value) {
            sp.edit().putString("last_sign", value).apply()
        }

    companion object {
        fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    }
}
