package com.junshi.tieba

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.CookieManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class MainActivity : Activity() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var prefs: Prefs
    private lateinit var statusView: TextView
    private lateinit var hintView: TextView
    private lateinit var logView: TextView
    private lateinit var loginBtn: Button
    private lateinit var runBtn: Button
    private lateinit var logoutBtn: Button
    private lateinit var autoSwitch: Switch
    private var running = false

    // ---------- 配色 ----------
    private val indigo = Color.parseColor("#3B4CCA")
    private val violet = Color.parseColor("#7B4DFF")
    private val mint = Color.parseColor("#12B886")
    private val danger = Color.parseColor("#E5484D")
    private val textMain = Color.parseColor("#1D2433")
    private val textSub = Color.parseColor("#6B7385")

    // ---------- 小工具 ----------
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int): GradientDrawable {
        val d = GradientDrawable()
        d.shape = GradientDrawable.RECTANGLE
        d.cornerRadius = dp(radiusDp).toFloat()
        d.setColor(color)
        return d
    }

    private fun lp(topMarginDp: Int): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        p.topMargin = dp(topMarginDp)
        return p
    }

    private fun card(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.background = rounded(Color.WHITE, 16)
        l.setPadding(dp(16), dp(16), dp(16), dp(16))
        l.elevation = dp(2).toFloat()
        return l
    }

    private fun label(text: String, sizeSp: Float, color: Int, bold: Boolean): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = sizeSp
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    private fun filledButton(text: String, color: Int): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.textSize = 16f
        b.setTextColor(Color.WHITE)
        b.background = rounded(color, 12)
        b.stateListAnimator = null
        return b
    }

    private fun outlineButton(text: String, color: Int): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.textSize = 14f
        b.setTextColor(color)
        val d = GradientDrawable()
        d.shape = GradientDrawable.RECTANGLE
        d.cornerRadius = dp(12).toFloat()
        d.setColor(Color.TRANSPARENT)
        d.setStroke(dp(1), color)
        b.background = d
        b.stateListAnimator = null
        return b
    }

    private fun appendLog(msg: String) {
        logView.append(msg + "\n")
    }

    // ---------- 界面 ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL

        // 顶部渐变头图
        val header = LinearLayout(this)
        header.orientation = LinearLayout.VERTICAL
        val r = dp(28).toFloat()
        val bg = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(indigo, violet)
        )
        bg.cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
        header.background = bg
        header.setPadding(dp(24), dp(36), dp(24), dp(28))

        header.addView(label("贴吧签到助手", 26f, Color.WHITE, true))
        header.addView(
            label("登录一次，每天自动签到", 14f, Color.parseColor("#CCFFFFFF"), false),
            lp(4)
        )

        statusView = label("○ 未登录", 13f, Color.WHITE, true)
        statusView.setPadding(dp(14), dp(6), dp(14), dp(6))
        statusView.background = rounded(Color.parseColor("#33FFFFFF"), 20)
        val chipLp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        chipLp.topMargin = dp(16)
        header.addView(statusView, chipLp)
        root.addView(header)

        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(16), dp(16), dp(16), dp(24))
        root.addView(content)

        // 卡片一：账号
        val accountCard = card()
        accountCard.addView(label("账号", 16f, textMain, true))
        hintView = label("", 13f, textSub, false)
        accountCard.addView(hintView, lp(4))

        loginBtn = filledButton("登录百度账号", indigo)
        accountCard.addView(loginBtn, lp(12))

        accountCard.addView(label("或手动粘贴 BDUSS", 12f, textSub, false), lp(14))
        val input = EditText(this)
        input.hint = "BDUSS"
        input.textSize = 14f
        input.setSingleLine(true)
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        input.background = rounded(Color.parseColor("#F1F3F9"), 10)
        input.setPadding(dp(12), dp(10), dp(12), dp(10))
        accountCard.addView(input, lp(6))

        val saveBtn = outlineButton("保存 BDUSS", indigo)
        accountCard.addView(saveBtn, lp(8))
        content.addView(accountCard, lp(0))

        // 卡片二：签到
        val signCard = card()
        signCard.addView(label("签到", 16f, textMain, true))

        runBtn = filledButton("立即签到", mint)
        signCard.addView(runBtn, lp(12))

        autoSwitch = Switch(this)
        autoSwitch.text = "自动签到"
        autoSwitch.textSize = 16f
        autoSwitch.setTextColor(textMain)
        autoSwitch.isChecked = prefs.auto
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        autoSwitch.thumbTintList = ColorStateList(
            states, intArrayOf(indigo, Color.parseColor("#B0B7C9"))
        )
        autoSwitch.trackTintList = ColorStateList(
            states, intArrayOf(Color.parseColor("#9AA5F0"), Color.parseColor("#DDE1EA"))
        )
        signCard.addView(autoSwitch, lp(16))
        signCard.addView(
            label("打开 App 时自动补签，每天约 00:30 后台签到", 12f, textSub, false),
            lp(2)
        )
        content.addView(signCard, lp(14))

        // 卡片三：日志
        val logCard = card()
        val logHeader = LinearLayout(this)
        logHeader.orientation = LinearLayout.HORIZONTAL
        logHeader.gravity = Gravity.CENTER_VERTICAL
        val logTitle = label("运行日志", 16f, textMain, true)
        logHeader.addView(
            logTitle,
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        val copyView = label("复制", 14f, indigo, true)
        logHeader.addView(copyView)
        logCard.addView(logHeader)

        logView = TextView(this)
        logView.textSize = 12f
        logView.typeface = Typeface.MONOSPACE
        logView.setTextColor(Color.parseColor("#A7F3D0"))
        logView.background = rounded(Color.parseColor("#101828"), 12)
        logView.setPadding(dp(12), dp(12), dp(12), dp(12))
        logView.minHeight = dp(140)
        logView.setTextIsSelectable(true)
        logView.text = "就绪\n"
        logCard.addView(logView, lp(10))
        content.addView(logCard, lp(14))

        logoutBtn = outlineButton("退出登录", danger)
        content.addView(logoutBtn, lp(18))

        val footer = label("凭证仅保存在本机，不会上传到任何服务器", 12f, textSub, false)
        footer.gravity = Gravity.CENTER
        content.addView(footer, lp(12))

        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.addView(root)
        setContentView(scroll)

        // ---------- 事件 ----------
        loginBtn.setOnClickListener {
            startActivityForResult(Intent(this, LoginActivity::class.java), REQ_LOGIN)
        }

        saveBtn.setOnClickListener {
            val v = input.text.toString().trim()
            if (v.isEmpty()) {
                Toast.makeText(this, "请先粘贴 BDUSS", Toast.LENGTH_SHORT).show()
            } else {
                prefs.bduss = v
                prefs.lastSign = ""
                input.setText("")
                appendLog("已保存手动填写的 BDUSS（长度 ${v.length}）")
                if (prefs.auto) Scheduler.start(this)
                refreshStatus()
                startSign()
            }
        }

        runBtn.setOnClickListener { startSign() }

        autoSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.auto = checked
            if (checked) {
                if (prefs.bduss.isNotEmpty()) Scheduler.start(this)
                appendLog("已开启自动签到")
            } else {
                Scheduler.stop(this)
                appendLog("已关闭自动签到")
            }
        }

        logoutBtn.setOnClickListener {
            prefs.bduss = ""
            prefs.lastSign = ""
            Scheduler.stop(this)
            CookieManager.getInstance().removeAllCookies(null)
            appendLog("已退出登录")
            refreshStatus()
        }

        copyView.setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("log", logView.text))
            Toast.makeText(this, "日志已复制", Toast.LENGTH_SHORT).show()
        }

        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        // 已登录、开启自动签到、今天还没签完 → 自动开始签到
        if (prefs.bduss.isNotEmpty() && prefs.auto && prefs.lastSign != Prefs.today()) {
            startSign()
        }
    }

    @Suppress("DEPRECATION")
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_LOGIN && resultCode == RESULT_OK) {
            appendLog("登录成功（已读取 BDUSS，长度 ${prefs.bduss.length}）")
            if (prefs.auto) Scheduler.start(this)
            refreshStatus()
            // 随后 onResume 会自动开始签到
        }
    }

    private fun refreshStatus() {
        val logged = prefs.bduss.isNotEmpty()
        statusView.text = if (logged) "● 已登录" else "○ 未登录"
        hintView.text = if (logged) {
            "已保存登录凭证，可以直接签到"
        } else {
            "登录后会自动读取凭证，无需手动复制"
        }
        loginBtn.text = if (logged) "重新登录" else "登录百度账号"
        runBtn.isEnabled = logged && !running
        runBtn.alpha = if (runBtn.isEnabled) 1f else 0.5f
        logoutBtn.isEnabled = logged
        logoutBtn.alpha = if (logged) 1f else 0.4f
    }

    private fun startSign() {
        if (running) return
        val bduss = prefs.bduss
        if (bduss.isEmpty()) return
        running = true
        runBtn.isEnabled = false
        runBtn.alpha = 0.5f
        runBtn.text = "签到中…"
        scope.launch {
            try {
                val r = TiebaClient(bduss).signAll { m -> runOnUiThread { appendLog(m) } }
                appendLog("完成：成功 ${r.success} / 已签 ${r.already} / 失败 ${r.failed}")
                if (r.failed == 0) prefs.lastSign = Prefs.today()
            } catch (e: Exception) {
                appendLog("出错：${e.message}")
            } finally {
                running = false
                runBtn.text = "立即签到"
                refreshStatus()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }

    companion object {
        private const val REQ_LOGIN = 100
    }
}
