# 贴吧签到助手

纯原生 Android（无 Compose），依赖：OkHttp、WorkManager、协程。

## 构建
- Gradle 8.0+、JDK 17
- `gradle assembleRelease`（已配置用 debug 证书签名，产出的 APK 可直接安装）

## 使用
1. 打开 App → 点“登录百度账号”，在内置页面登录（验证码在页面里手动完成）
2. 登录成功后自动签到；之后每次打开 App 会自动补签，后台每天约 00:30 也会签到
3. 不再需要手动复制 BDUSS

## 注意
- 登录凭证只保存在本机私有存储，勿分享手机或 APK 数据
- 使用的是贴吧客户端非公开接口，失效时需更新 TiebaClient.kt
- 国产系统请给 App 开启自启动/后台运行，否则后台定时任务可能被杀
