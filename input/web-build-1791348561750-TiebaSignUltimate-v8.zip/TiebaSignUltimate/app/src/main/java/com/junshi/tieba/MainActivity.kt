package com.junshi.tieba

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.text.Spanned
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.OvershootInterpolator
import android.webkit.CookieManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var prefs: Prefs
    private lateinit var statusView: TextView
    private lateinit var hintView: TextView
    private lateinit var logView: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var loginBtn: Button
    private lateinit var runBtn: Button
    private lateinit var logoutBtn: Button
    private lateinit var autoSwitch: Switch
    private var running = false

    private val logBuf = SpannableStringBuilder()
    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    // ---------- 配色：取自插画（紫发、霓虹青、深靛蓝） ----------
    private val cMain = Color.parseColor("#F4EFFF")
    private val cSub = Color.parseColor("#B9B0DA")
    private val cDim = Color.parseColor("#8A80B8")
    private val cCyan = Color.parseColor("#3EE0F0")
    private val cViolet = Color.parseColor("#7A4DFF")
    private val cDeep = Color.parseColor("#5B3FD0")
    private val cLav = Color.parseColor("#CFC4FF")
    private val cPink = Color.parseColor("#FF7A9A")
    private val cGold = Color.parseColor("#FFD98A")
    private val cMint = Color.parseColor("#5CF2C8")

    // ---------- 小工具 ----------
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun withAlpha(color: Int, a: Int): Int = (color and 0x00FFFFFF) or (a shl 24)

    private fun lp(topMarginDp: Int): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        p.topMargin = dp(topMarginDp)
        return p
    }

    private fun glass(fill: Int, stroke: Int, radiusDp: Int): GradientDrawable {
        val d = GradientDrawable()
        d.shape = GradientDrawable.RECTANGLE
        d.cornerRadius = dp(radiusDp).toFloat()
        d.setColor(fill)
        d.setStroke(dp(1), stroke)
        return d
    }

    private fun ripple(content: Drawable, radiusDp: Int): RippleDrawable {
        val mask = GradientDrawable()
        mask.shape = GradientDrawable.RECTANGLE
        mask.cornerRadius = dp(radiusDp).toFloat()
        mask.setColor(Color.WHITE)
        return RippleDrawable(ColorStateList.valueOf(Color.parseColor("#66FFFFFF")), content, mask)
    }

    /** 按下缩小 + 轻震动，松开时带一点回弹 */
    private fun addFeedback(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.animate().scaleX(0.96f).scaleY(0.96f).setDuration(90).start()
                    view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.animate().scaleX(1f).scaleY(1f).setDuration(180)
                        .setInterpolator(OvershootInterpolator(2.5f)).start()
                }
            }
            false
        }
    }

    private fun card(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.background = glass(Color.parseColor("#990C0824"), withAlpha(cCyan, 0x40), 20)
        l.setPadding(dp(16), dp(16), dp(16), dp(16))
        return l
    }

    private fun label(text: String, sizeSp: Float, color: Int, bold: Boolean): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = sizeSp
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    private fun gradientButton(text: String, from: Int, to: Int): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.textSize = 16f
        b.setTextColor(Color.WHITE)
        val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(from, to))
        g.cornerRadius = dp(14).toFloat()
        g.setStroke(dp(1), Color.parseColor("#66FFFFFF"))
        b.background = ripple(g, 14)
        b.stateListAnimator = null
        addFeedback(b)
        return b
    }

    private fun ghostButton(text: String, color: Int): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.textSize = 14f
        b.setTextColor(color)
        b.background = ripple(glass(withAlpha(color, 0x22), withAlpha(color, 0xAA), 14), 14)
        b.stateListAnimator = null
        addFeedback(b)
        return b
    }

    private fun greeting(): String {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when {
            h in 5..10 -> "早安，今天的签到我来盯着。"
            h in 11..17 -> "午安，记得喝点水，剩下的交给我。"
            h in 18..22 -> "晚上好，辛苦一天了，签到我来办。"
            else -> "夜深了，早点休息，这边有我。"
        }
    }

    // ---------- 日志：带时间、图标、分色 ----------
    private fun classify(m: String): Triple<String, Int, Boolean> = when {
        m.startsWith("完成") -> Triple("★", cGold, true)
        m.contains("失败") || m.contains("异常") || m.contains("出错") || m.contains("错误") ->
            Triple("✖", cPink, false)
        m.contains("成功") -> Triple("♥", cMint, false)
        m.contains("已签") || m.contains("已经") -> Triple("✿", cGold, false)
        else -> Triple("✦", cLav, false)
    }

    private fun appendLog(msg: String) {
        val (icon, color, bold) = classify(msg)
        val s0 = logBuf.length
        logBuf.append(timeFmt.format(Date())).append(" ")
        logBuf.setSpan(
            ForegroundColorSpan(cDim), s0, logBuf.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        val s1 = logBuf.length
        logBuf.append(icon).append(" ").append(msg).append("\n")
        logBuf.setSpan(
            ForegroundColorSpan(color), s1, logBuf.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        if (bold) {
            logBuf.setSpan(
                StyleSpan(Typeface.BOLD), s1, logBuf.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
        if (logBuf.length > 12000) logBuf.delete(0, 3000)
        logView.text = logBuf
        logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
    }

    // ---------- 界面 ----------
    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        window.statusBarColor = Color.TRANSPARENT
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val sbId = resources.getIdentifier("status_bar_height", "dimen", "android")
        val sbH = if (sbId > 0) resources.getDimensionPixelSize(sbId) else dp(24)

        // 底层：插画背景（固定不动），上层：可滚动内容
        val root = FrameLayout(this)
        val bgImg = ImageView(this)
        bgImg.scaleType = ImageView.ScaleType.CENTER_CROP
        bgImg.setImageResource(R.drawable.bg_art)
        root.addView(
            bgImg,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        root.addView(
            scroll,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), sbH + dp(12), dp(16), dp(32))
        scroll.addView(col)

        // 标题（左上角，避开人物）
        val title = label("贴吧签到助手", 24f, Color.WHITE, true)
        title.setShadowLayer(12f, 0f, 2f, Color.parseColor("#CC000000"))
        col.addView(title)
        val sub = label(greeting(), 13f, cLav, false)
        sub.setShadowLayer(10f, 0f, 2f, Color.parseColor("#CC000000"))
        col.addView(sub, lp(4))

        statusView = label("○ 等你登录", 13f, cLav, true)
        statusView.setPadding(dp(14), dp(6), dp(14), dp(6))
        statusView.background = glass(Color.parseColor("#66120C34"), withAlpha(cLav, 0x80), 20)
        val chipLp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        chipLp.topMargin = dp(10)
        col.addView(statusView, chipLp)

        // 留白：让人物的脸完整露出来
        val spacerH = (resources.displayMetrics.heightPixels * 0.40f).toInt() - sbH - dp(130)
        val spacer = View(this)
        col.addView(
            spacer,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, if (spacerH < dp(110)) dp(110) else spacerH
            )
        )

        // 卡片一：账号
        val accountCard = card()
        accountCard.addView(label("✦ 账号", 16f, cMain, true))
        hintView = label("", 13f, cSub, false)
        accountCard.addView(hintView, lp(4))

        loginBtn = gradientButton("登录百度账号", cViolet, withAlpha(cDeep, 0xE0))
        accountCard.addView(loginBtn, lp(12))

        accountCard.addView(label("或手动粘贴 BDUSS", 12f, cSub, false), lp(14))
        val input = EditText(this)
        input.hint = "BDUSS"
        input.textSize = 14f
        input.setTextColor(cMain)
        input.setHintTextColor(cDim)
        input.setSingleLine(true)
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        input.background = glass(Color.parseColor("#55000014"), withAlpha(cLav, 0x50), 12)
        input.setPadding(dp(12), dp(10), dp(12), dp(10))
        accountCard.addView(input, lp(6))

        val saveBtn = ghostButton("保存 BDUSS", cCyan)
        accountCard.addView(saveBtn, lp(8))
        col.addView(accountCard, lp(0))

        // 卡片二：签到
        val signCard = card()
        signCard.addView(label("✦ 签到", 16f, cMain, true))

        runBtn = gradientButton("立即签到", cDeep, withAlpha(cCyan, 0xE0))
        signCard.addView(runBtn, lp(12))

        autoSwitch = Switch(this)
        autoSwitch.text = "自动签到"
        autoSwitch.textSize = 16f
        autoSwitch.setTextColor(cMain)
        autoSwitch.isChecked = prefs.auto
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        autoSwitch.thumbTintList = ColorStateList(states, intArrayOf(cCyan, Color.parseColor("#9A92C0")))
        autoSwitch.trackTintList = ColorStateList(
            states, intArrayOf(withAlpha(cViolet, 0xAA), Color.parseColor("#44FFFFFF"))
        )
        signCard.addView(autoSwitch, lp(16))
        signCard.addView(label("打开 App 时自动补签，每天约 00:30 后台签到", 12f, cSub, false), lp(2))
        col.addView(signCard, lp(14))

        // 卡片三：日志
        val logCard = card()
        val logHeader = LinearLayout(this)
        logHeader.orientation = LinearLayout.HORIZONTAL
        logHeader.gravity = Gravity.CENTER_VERTICAL
        logHeader.addView(
            label("✦ 运行日志", 16f, cMain, true),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        val copyView = label("复制", 14f, cCyan, true)
        copyView.setPadding(dp(8), dp(4), dp(8), dp(4))
        addFeedback(copyView)
        logHeader.addView(copyView)
        logCard.addView(logHeader)

        logView = TextView(this)
        logView.textSize = 12f
        logView.typeface = Typeface.MONOSPACE
        logView.setTextColor(cLav)
        logView.setPadding(dp(12), dp(12), dp(12), dp(12))
        logView.setTextIsSelectable(true)
        logScroll = ScrollView(this)
        logScroll.background = glass(Color.parseColor("#B3050314"), withAlpha(cCyan, 0x40), 14)
        logScroll.addView(logView)
        logScroll.setOnTouchListener { v, _ ->
            v.parent.requestDisallowInterceptTouchEvent(true)
            false
        }
        logCard.addView(
            logScroll,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(230)).also {
                it.topMargin = dp(10)
            }
        )
        col.addView(logCard, lp(14))

        logoutBtn = ghostButton("退出登录", cPink)
        col.addView(logoutBtn, lp(18))

        val footer = label("凭证仅保存在本机，不会上传到任何服务器", 12f, cDim, false)
        footer.gravity = Gravity.CENTER
        col.addView(footer, lp(12))

        setContentView(root)
        appendLog("就绪，等你吩咐。")

        // ---------- 事件 ----------
        loginBtn.setOnClickListener {
            startActivityForResult(Intent(this, LoginActivity::class.java), REQ_LOGIN)
        }

        saveBtn.setOnClickListener {
            val v = input.text.toString().trim()
            if (v.isEmpty()) {
                Toast.makeText(this, "请先粘贴 BDUSS", Toast.LENGTH_SHORT).show()
            } else {
                prefs.bduss = v
                prefs.lastSign = ""
                input.setText("")
                appendLog("已保存手动填写的 BDUSS（长度 ${v.length}）")
                if (prefs.auto) Scheduler.start(this)
                refreshStatus()
                startSign()
            }
        }

        runBtn.setOnClickListener { startSign() }

        autoSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.auto = checked
            if (checked) {
                if (prefs.bduss.isNotEmpty()) Scheduler.start(this)
                appendLog("已开启自动签到")
            } else {
                Scheduler.stop(this)
                appendLog("已关闭自动签到")
            }
        }

        logoutBtn.setOnClickListener {
            prefs.bduss = ""
            prefs.lastSign = ""
            Scheduler.stop(this)
            CookieManager.getInstance().removeAllCookies(null)
            appendLog("已退出登录")
            refreshStatus()
        }

        copyView.setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("log", logView.text))
            Toast.makeText(this, "日志已复制", Toast.LENGTH_SHORT).show()
        }

        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        // 已登录、开启自动签到、今天还没签完 → 自动开始签到
        if (prefs.bduss.isNotEmpty() && prefs.auto && prefs.lastSign != Prefs.today()) {
            startSign()
        }
    }

    @Suppress("DEPRECATION")
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_LOGIN && resultCode == RESULT_OK) {
            appendLog("登录成功（已读取 BDUSS，长度 ${prefs.bduss.length}）")
            if (prefs.auto) Scheduler.start(this)
            refreshStatus()
            // 随后 onResume 会自动开始签到
        }
    }

    private fun refreshStatus() {
        val logged = prefs.bduss.isNotEmpty()
        statusView.text = if (logged) "● 已就位" else "○ 等你登录"
        statusView.setTextColor(if (logged) cCyan else cLav)
        hintView.text = if (logged) {
            "已经记住你了，放心交给我。"
        } else {
            "还不认识你呢，先登录吧，凭证会自动读取。"
        }
        loginBtn.text = if (logged) "重新登录" else "登录百度账号"
        runBtn.isEnabled = logged && !running
        runBtn.alpha = if (runBtn.isEnabled) 1f else 0.5f
        logoutBtn.isEnabled = logged
        logoutBtn.alpha = if (logged) 1f else 0.4f
    }

    private fun startSign() {
        if (running) return
        val bduss = prefs.bduss
        if (bduss.isEmpty()) return
        running = true
        runBtn.isEnabled = false
        runBtn.alpha = 0.5f
        runBtn.text = "处理中…"
        scope.launch {
            try {
                val r = TiebaClient(bduss).signAll { m -> runOnUiThread { appendLog(m) } }
                appendLog("完成：成功 ${r.success} / 已签 ${r.already} / 失败 ${r.failed}")
                if (r.failed == 0) {
                    prefs.lastSign = Prefs.today()
                    appendLog("全部搞定，辛苦啦。")
                } else {
                    appendLog("还有 ${r.failed} 个没成功，稍后我会再试。")
                }
            } catch (e: Exception) {
                appendLog("出错：${e.message}")
            } finally {
                running = false
                runBtn.text = "立即签到"
                refreshStatus()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }

    companion object {
        private const val REQ_LOGIN = 100
    }
}
