package com.junshi.tieba
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.*
import org.json.JSONObject
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
data class Forum(val name:String,val signed:Boolean)
data class SignSummary(val total:Int,val success:Int,val skipped:Int,val failed:Int)
class TiebaClient(private val s:SecureStore){private val h=OkHttpClient.Builder().connectTimeout(15,TimeUnit.SECONDS).readTimeout(20,TimeUnit.SECONDS).build();private val web="https://tieba.baidu.com";private val app="https://tiebac.baidu.com";private val cv="12.64.1.1";private fun cookie()="BDUSS=${s.bduss}; STOKEN=${s.stoken};";private fun req(r:Request)=h.newCall(r).execute().use{if(!it.isSuccessful)error("HTTP ${it.code}");it.body?.string()?: ""};private fun form(vararg p:Pair<String,String>)=FormBody.Builder().apply{p.forEach{add(it.first,it.second)}}.build()
suspend fun tbs():String{val j=JSONObject(req(Request.Builder().url("$web/dc/common/tbs").header("Cookie",cookie()).build()));if(j.optInt("is_login")!=1)error("未登录或登录态失效");return j.getString("tbs")}
suspend fun forums(t:String):List<Forum>{val a=mutableListOf<Forum>();for(page in 1..9999){val b=form("tbs" to t,"sort_type" to "3","call_from" to "3","page_no" to page.toString(),"res_num" to "200");val j=JSONObject(req(Request.Builder().url("$web/c/f/forum/forumGuide").header("Cookie",cookie()).post(b).build()));if(j.optInt("error_code")!=0)error(j.optString("error_msg"));val x=j.optJSONArray("like_forum")?:break;for(i in 0 until x.length()){val f=x.getJSONObject(i);a+=Forum(f.optString("forum_name"),f.optInt("is_sign")==1)};if(!j.optBoolean("like_forum_has_more"))break;delay(250)};return a.distinctBy{it.name}}
private fun md5(x:String)=MessageDigest.getInstance("MD5").digest(x.toByteArray()).joinToString(""){"%02x".format(it)}
private fun sign(k:String,t:String)=md5("BDUSS=${s.bduss}_client_version=$cv"+"kw=$k"+"tbs=$t"+"tiebaclient!!!")
suspend fun multi():Boolean{val j=JSONObject(req(Request.Builder().url("$web/c/c/forum/msign").header("Cookie",cookie()).post(form("_client_version" to cv,"subapp_type" to "hybrid")).build()));return j.optInt("error_code")==0 && (j.optJSONObject("error")?.optInt("errno",0)?:0)==0}
suspend fun one(k:String,t:String):String{val j=JSONObject(req(Request.Builder().url("$app/c/c/forum/sign").header("Cookie",cookie()).post(form("BDUSS" to s.bduss,"_client_version" to cv,"kw" to k,"tbs" to t,"sign" to sign(k,t))).build()));if(j.optInt("error_code")!=0)return "失败：${j.optString("error_msg")}";val p=j.optJSONObject("user_info")?.optInt("sign_bonus_point",0)?:0;return if(p>0)"成功 +$p 经验" else "已签到/未获得经验"}
suspend fun run(log:(String)->Unit):SignSummary=withContext(Dispatchers.IO){runInternal(log)}
private suspend fun runInternal(log:(String)->Unit):SignSummary{require(s.bduss.isNotBlank()){"未配置 BDUSS"};val t=tbs();val fs=forums(t);val targets=fs.filterNot{it.signed};log("关注 ${fs.size} 个，待签到 ${targets.size} 个");var ok=0;var skip=fs.count{it.signed};var fail=0;val all=try{multi()}catch(e:Exception){false};if(all){ok=targets.size;log("一键签到完成")}else{log("一键签到不可用，转逐吧模式");for(f in targets){try{val r=one(f.name,t);if(r.startsWith("成功"))ok++ else skip++;log("${f.name}：$r")}catch(e:Exception){fail++;log("${f.name}：失败 ${e.message}")};delay(800)}};return SignSummary(fs.size,ok,skip,fail)}}
