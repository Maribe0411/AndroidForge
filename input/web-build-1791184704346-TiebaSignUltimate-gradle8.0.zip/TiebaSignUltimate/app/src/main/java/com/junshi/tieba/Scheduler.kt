package com.junshi.tieba
import android.content.Context
import androidx.work.*
import java.util.concurrent.TimeUnit
object Scheduler{fun start(c:Context){val r=PeriodicWorkRequestBuilder<SignWorker>(24,TimeUnit.HOURS).setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build();WorkManager.getInstance(c).enqueueUniquePeriodicWork("tieba_daily",ExistingPeriodicWorkPolicy.UPDATE,r)};fun stop(c:Context)=WorkManager.getInstance(c).cancelUniqueWork("tieba_daily")}
