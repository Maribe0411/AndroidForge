package com.junshi.tieba
import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
class SecureStore(c: Context){private val key=MasterKey.Builder(c).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build();private val p=EncryptedSharedPreferences.create(c,"tieba_credentials",key,EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM);var bduss:String get()=p.getString("bduss","")?:"" set(v){p.edit().putString("bduss",v).apply()};var stoken:String get()=p.getString("stoken","")?:"" set(v){p.edit().putString("stoken",v).apply()}}
