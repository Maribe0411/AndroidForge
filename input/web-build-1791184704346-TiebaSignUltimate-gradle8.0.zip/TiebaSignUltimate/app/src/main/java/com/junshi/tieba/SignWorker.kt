package com.junshi.tieba
import android.app.*
import android.content.Context
import androidx.core.app.NotificationCompat
import androidx.work.*
class SignWorker(c:Context,p:WorkerParameters):CoroutineWorker(c,p){override suspend fun doWork():Result=try{val r=TiebaClient(SecureStore(applicationContext)).run{};notify("成功 ${r.success} · 跳过 ${r.skipped} · 失败 ${r.failed}");Result.success()}catch(e:Exception){notify("签到失败：${e.message}");Result.retry()};private fun notify(x:String){val n=applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager;val id="tieba";n.createNotificationChannel(NotificationChannel(id,"贴吧签到",NotificationManager.IMPORTANCE_DEFAULT));n.notify(7,NotificationCompat.Builder(applicationContext,id).setSmallIcon(android.R.drawable.ic_popup_sync).setContentTitle("贴吧签到助手").setContentText(x).setAutoCancel(true).build())}}
