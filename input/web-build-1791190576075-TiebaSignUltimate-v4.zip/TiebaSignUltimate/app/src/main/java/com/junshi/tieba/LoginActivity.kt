package com.junshi.tieba

import android.app.Activity
import android.net.Uri
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

/** 在 App 内打开百度登录页，登录成功后自动读取 BDUSS，无需手动复制。 */
class LoginActivity : Activity() {

    private var done = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val webView = WebView(this)
        setContentView(webView)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                checkCookie()
            }
        }

        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        val loginUrl = "https://wappass.baidu.com/passport/?login&u=" +
            Uri.encode("https://tieba.baidu.com/")
        // 先清掉旧 Cookie，避免读到上一个账号的登录态
        cm.removeAllCookies {
            webView.loadUrl(loginUrl)
        }
    }

    private fun readCookie(all: String, name: String): String? {
        return all.split(";")
            .map { it.trim() }
            .firstOrNull { it.startsWith("$name=") }
            ?.substringAfter("=")
    }

    private fun checkCookie() {
        if (done) return
        val cm = CookieManager.getInstance()
        val all = listOf(
            "https://tieba.baidu.com",
            "https://www.baidu.com",
            "https://passport.baidu.com"
        ).mapNotNull { cm.getCookie(it) }.joinToString(";")

        val found = readCookie(all, "BDUSS") ?: readCookie(all, "BDUSS_BFESS")
        if (!found.isNullOrEmpty()) {
            done = true
            val p = Prefs(this)
            p.bduss = found
            p.lastSign = ""
            Toast.makeText(this, "登录成功", Toast.LENGTH_SHORT).show()
            setResult(RESULT_OK)
            finish()
        }
    }
}
