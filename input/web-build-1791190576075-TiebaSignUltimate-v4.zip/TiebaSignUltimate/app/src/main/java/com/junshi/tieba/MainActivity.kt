package com.junshi.tieba

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.webkit.CookieManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class MainActivity : Activity() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var prefs: Prefs
    private lateinit var statusView: TextView
    private lateinit var logView: TextView
    private lateinit var loginBtn: Button
    private lateinit var runBtn: Button
    private lateinit var logoutBtn: Button
    private lateinit var autoSwitch: Switch
    private var running = false

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun lp(topMarginDp: Int): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        p.topMargin = dp(topMarginDp)
        return p
    }

    private fun appendLog(msg: String) {
        logView.append(msg + "\n")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(16), dp(16), dp(16))

        val title = TextView(this)
        title.text = "贴吧签到助手"
        title.textSize = 22f
        root.addView(title)

        statusView = TextView(this)
        statusView.textSize = 15f
        root.addView(statusView, lp(8))

        loginBtn = Button(this)
        root.addView(loginBtn, lp(12))

        val input = EditText(this)
        input.hint = "或手动粘贴 BDUSS"
        input.setSingleLine(true)
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        root.addView(input, lp(8))

        val saveBtn = Button(this)
        saveBtn.text = "保存手动填写的 BDUSS"
        root.addView(saveBtn, lp(4))

        runBtn = Button(this)
        runBtn.text = "立即签到"
        root.addView(runBtn, lp(12))

        autoSwitch = Switch(this)
        autoSwitch.text = "自动签到（打开 App 时补签 + 每天约 00:30）"
        autoSwitch.isChecked = prefs.auto
        root.addView(autoSwitch, lp(12))

        logoutBtn = Button(this)
        logoutBtn.text = "退出登录"
        root.addView(logoutBtn, lp(12))

        val copyBtn = Button(this)
        copyBtn.text = "复制日志"
        root.addView(copyBtn, lp(4))

        logView = TextView(this)
        logView.textSize = 13f
        logView.setTextIsSelectable(true)
        logView.text = "就绪\n"
        root.addView(logView, lp(12))

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        loginBtn.setOnClickListener {
            startActivityForResult(Intent(this, LoginActivity::class.java), REQ_LOGIN)
        }

        saveBtn.setOnClickListener {
            val v = input.text.toString().trim()
            if (v.isEmpty()) {
                Toast.makeText(this, "请先粘贴 BDUSS", Toast.LENGTH_SHORT).show()
            } else {
                prefs.bduss = v
                prefs.lastSign = ""
                input.setText("")
                appendLog("已保存手动填写的 BDUSS（长度 ${v.length}）")
                if (prefs.auto) Scheduler.start(this)
                refreshStatus()
                startSign()
            }
        }

        runBtn.setOnClickListener { startSign() }

        autoSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.auto = checked
            if (checked) {
                if (prefs.bduss.isNotEmpty()) Scheduler.start(this)
                appendLog("已开启自动签到")
            } else {
                Scheduler.stop(this)
                appendLog("已关闭自动签到")
            }
        }

        logoutBtn.setOnClickListener {
            prefs.bduss = ""
            prefs.lastSign = ""
            Scheduler.stop(this)
            CookieManager.getInstance().removeAllCookies(null)
            appendLog("已退出登录")
            refreshStatus()
        }

        copyBtn.setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("log", logView.text))
            Toast.makeText(this, "日志已复制", Toast.LENGTH_SHORT).show()
        }

        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        // 已登录、开启自动签到、今天还没签完 → 自动开始签到
        if (prefs.bduss.isNotEmpty() && prefs.auto && prefs.lastSign != Prefs.today()) {
            startSign()
        }
    }

    @Suppress("DEPRECATION")
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_LOGIN && resultCode == RESULT_OK) {
            appendLog("登录成功（已读取 BDUSS，长度 ${prefs.bduss.length}）")
            if (prefs.auto) Scheduler.start(this)
            refreshStatus()
            // 随后 onResume 会自动开始签到
        }
    }

    private fun refreshStatus() {
        val logged = prefs.bduss.isNotEmpty()
        statusView.text = if (logged) "状态：已登录（凭证仅保存在本机）" else "状态：未登录"
        loginBtn.text = if (logged) "重新登录" else "登录百度账号"
        runBtn.isEnabled = logged && !running
        logoutBtn.isEnabled = logged
    }

    private fun startSign() {
        if (running) return
        val bduss = prefs.bduss
        if (bduss.isEmpty()) return
        running = true
        runBtn.isEnabled = false
        runBtn.text = "签到中…"
        scope.launch {
            try {
                val r = TiebaClient(bduss).signAll { m -> runOnUiThread { appendLog(m) } }
                appendLog("完成：成功 ${r.success} / 已签 ${r.already} / 失败 ${r.failed}")
                if (r.failed == 0) prefs.lastSign = Prefs.today()
            } catch (e: Exception) {
                appendLog("出错：${e.message}")
            } finally {
                running = false
                runBtn.text = "立即签到"
                refreshStatus()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }

    companion object {
        private const val REQ_LOGIN = 100
    }
}
