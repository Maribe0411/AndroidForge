package com.junshi.tieba

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import kotlin.random.Random

data class Forum(val id: String, val name: String)

data class SignSummary(val total: Int, val success: Int, val already: Int, val failed: Int)

/**
 * 思路参考 GitHub 上常见的贴吧签到脚本（如 ghosx/TieBaSign）：
 * 1. 用 BDUSS 请求 tbs
 * 2. 用客户端接口分页获取关注的吧
 * 3. 用客户端签到接口逐个签到（参数按 key 排序后拼接 + "tiebaclient!!!" 做 MD5 签名）
 * 接口是非公开接口，百度随时可能调整，失效时需要更新这里。
 */
class TiebaClient(private val bduss: String) {

    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .followRedirects(false)
        .followSslRedirects(false)
        .build()

    private val tbsUrl = "https://tieba.baidu.com/dc/common/tbs"
    private val likeUrl = "https://c.tieba.baidu.com/c/f/forum/like"
    private val signUrl = "https://c.tieba.baidu.com/c/c/forum/sign"

    private val ua = "Mozilla/5.0 (Linux; Android 10; MI 5) AppleWebKit/537.36 " +
        "(KHTML, like Gecko) Chrome/80.0.3987.162 Mobile Safari/537.36"

    private fun baseParams(): MutableMap<String, String> = mutableMapOf(
        "_client_type" to "2",
        "_client_version" to "9.7.8.0",
        "_phone_imei" to "000000000000000",
        "model" to "MI+5",
        "net_type" to "1"
    )

    private fun md5(s: String): String {
        val bytes = MessageDigest.getInstance("MD5")
            .digest(s.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    /** 按 key 排序拼接，末尾加 tiebaclient!!!，MD5 后转大写作为 sign。 */
    private fun signedBody(params: Map<String, String>): FormBody {
        val sorted = params.toSortedMap()
        val raw = sorted.entries.joinToString("") { it.key + "=" + it.value } +
            "tiebaclient!!!"

        val builder = FormBody.Builder()

        for ((k, v) in sorted) {
            builder.add(k, v)
        }

        builder.add("sign", md5(raw).uppercase())
        return builder.build()
    }

    private fun parseJson(body: String): JSONObject {
        try {
            return JSONObject(body)
        } catch (e: Exception) {
            throw IllegalStateException("返回内容不是 JSON：" + body.take(150))
        }
    }

    private fun execute(request: Request): String {
        http.newCall(request).execute().use { resp ->
            if (!resp.isSuccessful) {
                val location = resp.header("Location")

                if (!location.isNullOrBlank()) {
                    throw IllegalStateException(
                        "HTTP ${resp.code}，服务器要求跳转到：$location"
                    )
                }

                throw IllegalStateException("HTTP ${resp.code}")
            }

            return resp.body?.string() ?: ""
        }
    }

    private val pcUa = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
        "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

    /**
     * 手动跟随跳转，不改协议；用一个简易 Cookie 表保存服务器中途下发的 Cookie
     * （百度的 red_tag 跳转通常需要带着它再请求一次）。
     */
    private fun fetchFollowing(startUrl: String, userAgent: String): String {
        var url = startUrl
        val cookies = linkedMapOf("BDUSS" to bduss)

        repeat(6) {
            val req = Request.Builder()
                .url(url)
                .header("Cookie", cookies.entries.joinToString("; ") { it.key + "=" + it.value })
                .header("User-Agent", userAgent)
                .header("Accept", "application/json, text/javascript, */*; q=0.01")
                .build()

            http.newCall(req).execute().use { resp ->
                for (c in resp.headers("Set-Cookie")) {
                    val kv = c.substringBefore(";")
                    val k = kv.substringBefore("=").trim()
                    val v = kv.substringAfter("=", "").trim()
                    if (k.isNotEmpty() && k != "BDUSS") cookies[k] = v
                }

                if (resp.code in 300..399) {
                    val loc = resp.header("Location")
                        ?: throw IllegalStateException("HTTP ${resp.code} 且无 Location")
                    url = resp.request.url.resolve(loc)?.toString()
                        ?: throw IllegalStateException("无法解析跳转地址：$loc")
                    return@use
                }
                if (!resp.isSuccessful) {
                    throw IllegalStateException("HTTP ${resp.code}")
                }
                return resp.body?.string() ?: ""
            }
        }
        throw IllegalStateException("跳转次数过多，最后地址：$url")
    }

    /** 客户端登录接口里自带 tbs（anti.tbs），作为网页接口失败时的备用。 */
    private fun getTbsFromClient(): String {
        val params = baseParams()
        params["BDUSS"] = bduss
        params["_client_id"] = "wappc_1534235498291_488"
        params["timestamp"] = (System.currentTimeMillis() / 1000).toString()

        val req = Request.Builder()
            .url("https://c.tieba.baidu.com/c/s/login")
            .header("User-Agent", ua)
            .post(signedBody(params))
            .build()

        val json = parseJson(execute(req))
        val tbs = json.optJSONObject("anti")?.optString("tbs").orEmpty()

        if (tbs.isEmpty()) {
            throw IllegalStateException(
                "客户端接口未返回 tbs：" + json.toString().take(150)
            )
        }
        return tbs
    }

    private fun getTbs(): String {
        val errors = mutableListOf<String>()

        // 网页接口：先 http（脚本常用地址），再 https；每个地址试电脑 UA 和手机 UA
        for (u in listOf(
            "http://tieba.baidu.com/dc/common/tbs",
            "https://tieba.baidu.com/dc/common/tbs"
        )) {
            for (agent in listOf(pcUa, ua)) {
                try {
                    val json = parseJson(fetchFollowing(u, agent))

                    if (json.optInt("is_login") != 1) {
                        throw IllegalStateException("BDUSS 无效或已过期，请重新获取")
                    }
                    return json.getString("tbs")
                } catch (e: Exception) {
                    if (e.message?.startsWith("BDUSS") == true) throw e
                    errors.add(u.substringBefore("://") + ": " + e.message)
                }
            }
        }

        // 备用：客户端接口
        try {
            return getTbsFromClient()
        } catch (e: Exception) {
            errors.add("客户端: " + e.message)
        }

        throw IllegalStateException("获取 tbs 失败（" + errors.distinct().joinToString("；") + "）")
    }

    private suspend fun getForums(onLog: (String) -> Unit): List<Forum> {
        val result = LinkedHashMap<String, Forum>()
        var page = 1

        while (page <= 200) {
            val params = baseParams()

            params["BDUSS"] = bduss
            params["_client_id"] = "wappc_1534235498291_488"
            params["from"] = "1008621y"
            params["page_no"] = page.toString()
            params["page_size"] = "200"
            params["timestamp"] = (System.currentTimeMillis() / 1000).toString()
            params["vcode_tag"] = "11"

            val req = Request.Builder()
                .url(likeUrl)
                .header("User-Agent", ua)
                .post(signedBody(params))
                .build()

            val json = parseJson(execute(req))

            val list = json.optJSONObject("forum_list")

            if (list == null && json.optString("error_code", "0") != "0") {
                throw IllegalStateException(
                    "获取关注贴吧失败，错误码 " +
                        json.optString("error_code") +
                        " " +
                        json.optString("error_msg")
                )
            }

            if (list == null && page == 1) {
                onLog("接口返回（供排错）：" + json.toString().take(200))
            }

            if (list != null) {
                for (key in listOf("non-gconforum", "gconforum")) {
                    val arr = list.optJSONArray(key) ?: continue

                    for (i in 0 until arr.length()) {
                        val item = arr.getJSONObject(i)
                        val id = item.optString("id")
                        val name = item.optString("name")

                        if (id.isNotEmpty() && name.isNotEmpty()) {
                            result[id] = Forum(id, name)
                        }
                    }
                }
            }

            if (json.optString("has_more") != "1") {
                break
            }

            page++
            delay(300)
        }

        if (result.isEmpty()) {
            onLog("客户端接口返回 0 个贴吧，改用网页接口获取关注列表")
            try {
                for (f in getForumsFromWeb(onLog)) {
                    result[f.id] = f
                }
            } catch (e: Exception) {
                onLog("网页接口也失败：" + e.message)
            }
        }

        return result.values.toList()
    }

    /** 备用：网页端 newmoindex 接口，只需要 BDUSS，返回 data.like_forum 列表。 */
    private fun getForumsFromWeb(onLog: (String) -> Unit): List<Forum> {
        val errors = mutableListOf<String>()

        for (u in listOf(
            "http://tieba.baidu.com/mo/q/newmoindex",
            "https://tieba.baidu.com/mo/q/newmoindex"
        )) {
            for (agent in listOf(ua, pcUa)) {
                try {
                    val body = fetchFollowing(u, agent)
                    val json = parseJson(body)
                    val arr = json.optJSONObject("data")?.optJSONArray("like_forum")

                    if (arr == null) {
                        errors.add("无 like_forum：" + body.take(120))
                        continue
                    }

                    val list = mutableListOf<Forum>()
                    for (i in 0 until arr.length()) {
                        val item = arr.getJSONObject(i)
                        val id = item.optString("forum_id")
                        val name = item.optString("forum_name")
                        if (id.isNotEmpty() && name.isNotEmpty()) {
                            list.add(Forum(id, name))
                        }
                    }

                    if (list.isNotEmpty()) return list
                    errors.add("like_forum 为空")
                } catch (e: Exception) {
                    errors.add(e.message ?: "未知错误")
                }
            }
        }

        throw IllegalStateException(errors.distinct().joinToString("；"))
    }

    /** 返回：0 = 签到成功，1 = 已经签到过，2 = 失败（msg 里有原因） */
    private fun signOne(forum: Forum, tbs: String): Pair<Int, String> {
        val params = baseParams()

        params["BDUSS"] = bduss
        params["fid"] = forum.id
        params["kw"] = forum.name
        params["tbs"] = tbs
        params["timestamp"] = (System.currentTimeMillis() / 1000).toString()

        val req = Request.Builder()
            .url(signUrl)
            .header("User-Agent", ua)
            .header("Connection", "Keep-Alive")
            .post(signedBody(params))
            .build()

        val json = parseJson(execute(req))
        val code = json.optString("error_code", "")

        return when (code) {
            "0" -> Pair(0, "")
            "160002" -> Pair(1, "")
            else -> Pair(
                2,
                "错误码 ${code} ${json.optString("error_msg")}".trim()
            )
        }
    }

    suspend fun signAll(onLog: (String) -> Unit): SignSummary =
        withContext(Dispatchers.IO) {

            require(bduss.isNotBlank()) { "未填写 BDUSS" }

            val tbs = getTbs()
            onLog("登录状态正常")

            val forums = getForums(onLog)
            onLog("共关注 ${forums.size} 个贴吧")

            var success = 0
            var already = 0
            var pending = forums

            // 最多尝试 3 轮，失败的贴吧下一轮重试
            for (round in 1..3) {
                if (pending.isEmpty()) break

                if (round > 1) {
                    onLog("第 $round 轮重试，剩余 ${pending.size} 个")
                    delay(5000)
                }

                val failedNow = mutableListOf<Forum>()

                for (forum in pending) {
                    try {
                        val (state, msg) = signOne(forum, tbs)

                        when (state) {
                            0 -> {
                                success++
                                onLog("${forum.name}吧：签到成功")
                            }

                            1 -> {
                                already++
                                onLog("${forum.name}吧：今天已签到")
                            }

                            else -> {
                                failedNow.add(forum)
                                onLog("${forum.name}吧：失败 $msg")
                            }
                        }
                    } catch (e: Exception) {
                        failedNow.add(forum)
                        onLog("${forum.name}吧：异常 ${e.message}")
                    }

                    delay(Random.nextLong(800, 2000))
                }

                pending = failedNow
            }

            SignSummary(
                forums.size,
                success,
                already,
                pending.size
            )
        }
}